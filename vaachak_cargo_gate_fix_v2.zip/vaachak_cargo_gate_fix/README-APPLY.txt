Vaachak cargo gate fix

Apply from the repository root:

  unzip -o vaachak_cargo_gate_fix_v2.zip -d /tmp/vaachak-cargo-gate-fix
  /tmp/vaachak-cargo-gate-fix/vaachak_cargo_gate_fix/scripts/apply_vaachak_cargo_gate_fix.sh .

What it changes:
- Replaces vendor/pulp-os/src/apps/home.rs
- Replaces vendor/pulp-os/src/apps/network_time.rs
- Removes stale root-level *_overlay directories and *_overlay*.zip archives

Validation:

  cargo fmt --all --check
  cargo check --workspace --target riscv32imc-unknown-none-elf
  cargo clippy --workspace --target riscv32imc-unknown-none-elf -- -D warnings
  cargo build -p target-xteink-x4 --release --target riscv32imc-unknown-none-elf
  ./scripts/check_no_milestone_artifacts.sh .
  git diff --check
