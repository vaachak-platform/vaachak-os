#!/usr/bin/env bash
set -euo pipefail

repo_root="${1:-.}"
cd "$repo_root"

if [[ ! -f Cargo.toml || ! -d vendor/pulp-os/src/apps ]]; then
  echo "ERROR: run from vaachak-os repo root, or pass repo root as first argument" >&2
  exit 1
fi

pack_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

install -m 0644 "$pack_dir/files/vendor/pulp-os/src/apps/home.rs" \
  "vendor/pulp-os/src/apps/home.rs"
install -m 0644 "$pack_dir/files/vendor/pulp-os/src/apps/network_time.rs" \
  "vendor/pulp-os/src/apps/network_time.rs"

# Remove old root-level delivery packs that make check_no_milestone_artifacts.sh fail.
find . -maxdepth 1 -type d -name '*_overlay' -prune -exec rm -rf {} +
find . -maxdepth 1 -type f -name '*_overlay*.zip' -delete

printf '%s\n' 'applied vaachak cargo gate fix'
