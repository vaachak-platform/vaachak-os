#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
cd "$ROOT"

python3 - <<'PY'
from pathlib import Path
import re
import shutil
import sys
from datetime import datetime

root = Path.cwd()
stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup_root = root / ".vaachak_backups" / f"prepared-reader-stabilization-{stamp}"
errors = []


def rel(path: Path) -> str:
    return str(path.relative_to(root))


def backup(path: Path) -> None:
    if path.exists():
        dst = backup_root / path.relative_to(root)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if path.is_dir():
            shutil.copytree(path, dst)
        else:
            shutil.copy2(path, dst)


def read(path: Path) -> str:
    if not path.exists():
        errors.append(f"missing {rel(path)}")
        return ""
    return path.read_text()


def write(path: Path, text: str) -> None:
    backup(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def find_matching_brace(src: str, open_brace: int) -> int:
    depth = 0
    for i in range(open_brace, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return -1


def replace_function(src: str, fn_name: str, replacement: str, required: bool = True) -> str:
    starts = [
        src.find(f"    fn {fn_name}"),
        src.find(f"    pub fn {fn_name}"),
        src.find(f"fn {fn_name}"),
        src.find(f"pub fn {fn_name}"),
    ]
    start = next((p for p in starts if p >= 0), -1)
    if start < 0:
        if required:
            errors.append(f"could not find function {fn_name}")
        return src
    brace = src.find("{", start)
    end = find_matching_brace(src, brace) if brace >= 0 else -1
    if brace < 0 or end < 0:
        if required:
            errors.append(f"could not parse function {fn_name}")
        return src
    return src[:start] + replacement.rstrip() + "\n" + src[end + 1:]


def remove_function(src: str, fn_name: str) -> str:
    starts = [
        src.find(f"    fn {fn_name}"),
        src.find(f"    pub fn {fn_name}"),
        src.find(f"fn {fn_name}"),
        src.find(f"pub fn {fn_name}"),
    ]
    start = next((p for p in starts if p >= 0), -1)
    if start < 0:
        return src
    brace = src.find("{", start)
    end = find_matching_brace(src, brace) if brace >= 0 else -1
    if brace < 0 or end < 0:
        return src
    while end + 1 < len(src) and src[end + 1] in " \t\r\n":
        end += 1
    return src[:start].rstrip() + "\n\n" + src[end + 1:]


# ---------------------------------------------------------------------
# 1. Reader header cleanup: show Prep when active; show error code only
#    when a prepared-cache failure was actually recorded.
# ---------------------------------------------------------------------
reader = root / "vendor/pulp-os/src/apps/reader/mod.rs"
if reader.exists():
    text = read(reader)

    if "prepared_txt.is_active()" in text and "prepared_cache_debug_err" in text:
        status_fn = r'''    fn write_reader_status_label<const N: usize>(&self, out: &mut StackFmt<N>) {
        if self.prepared_txt.is_active() {
            let _ = write!(out, "Prep ");
            self.write_position_label(out, true);
            return;
        }

        if let (Some(id), Some(err)) = (self.prepared_cache_debug_id, self.prepared_cache_debug_err) {
            let id_str = core::str::from_utf8(&id).unwrap_or("????????");
            let _ = write!(out, "Read cache:{} err:{} ", id_str, err);
            self.write_position_label(out, true);
            return;
        }

        let _ = write!(out, "{}", READER_STATUS_PREFIX);
        self.write_position_label(out, true);
    }
'''
        text = replace_function(text, "write_reader_status_label", status_fn)

        # Remove any stale generic err:OPEN header text outside the diagnostics path.
        text = text.replace('let _ = write!(out, "Read cache:{} err:OPEN ", id);',
                            'let _ = write!(out, "{}", READER_STATUS_PREFIX);')
        text = text.replace('let _ = write!(out, "Read cache:{} err:OPEN ", id_str);',
                            'let _ = write!(out, "Read cache:{} ", id_str);')

    elif "write_reader_status_label" in text:
        # Fallback for trees where prepared diagnostics were not applied.
        status_fn = r'''    fn write_reader_status_label<const N: usize>(&self, out: &mut StackFmt<N>) {
        let _ = write!(out, "{}", READER_STATUS_PREFIX);
        self.write_position_label(out, true);
    }
'''
        text = replace_function(text, "write_reader_status_label", status_fn)

    write(reader, text)


# ---------------------------------------------------------------------
# 2. Prepared cache real-book limits and diagnostics.
# ---------------------------------------------------------------------
prepared = root / "vendor/pulp-os/src/apps/reader/prepared_txt.rs"
if prepared.exists():
    text = read(prepared)
    replacements = {
        r"const MAX_META_BYTES:\s*usize\s*=\s*[^;]+;": "const MAX_META_BYTES: usize = 1024;",
        r"const MAX_INDEX_BYTES:\s*usize\s*=\s*[^;]+;": "const MAX_INDEX_BYTES: usize = 4 * 1024;",
        r"const MAX_FONT_BYTES:\s*usize\s*=\s*[^;]+;": "const MAX_FONT_BYTES: usize = 16 * 1024;",
        r"const MAX_PAGE_BYTES:\s*usize\s*=\s*[^;]+;": "const MAX_PAGE_BYTES: usize = 24 * 1024;",
        r"const MAX_PAGES:\s*usize\s*=\s*[^;]+;": "const MAX_PAGES: usize = 192;",
        r"const MAX_GLYPHS:\s*usize\s*=\s*[^;]+;": "const MAX_GLYPHS: usize = 1024;",
    }
    for pattern, repl in replacements.items():
        text, n = re.subn(pattern, repl, text, count=1)
        if n != 1:
            errors.append(f"could not patch prepared limit: {repl}")

    # Keep source matching permissive so FAT case/8.3 display names do not reject a valid cache.
    if "fn source_matches" in text:
        source_fn = r'''fn source_matches(_cache_source: &str, _reader_source: &str) -> bool {
    // The prepared cache directory/book_id is the authority.
    // Do not reject a cache because FAT 8.3 names, case, or leading slashes differ.
    true
}
'''
        text = replace_function(text, "source_matches", source_fn, required=False)

    # Some source-normalization helpers become unused after permissive source matching.
    for name in ["path_basename", "normalized_eq", "normalize_path_byte"]:
        marker = f"fn {name}"
        allow = f"#[allow(dead_code)]\nfn {name}"
        if marker in text and allow not in text:
            text = text.replace(marker, allow, 1)

    write(prepared, text)


# ---------------------------------------------------------------------
# 3. Clean unused USB transfer scaffolding if present.
#    This keeps Wi-Fi transfer as the supported large-transfer path.
# ---------------------------------------------------------------------
for d in [
    root / "tools/usb_transfer",
    root / "vendor/pulp-os/src/apps/usb_transfer",
]:
    if d.exists():
        backup(d)
        shutil.rmtree(d)

apps_mod = root / "vendor/pulp-os/src/apps/mod.rs"
if apps_mod.exists():
    text = read(apps_mod)
    text = re.sub(r"^\s*pub\s+mod\s+usb_transfer;\s*\n", "", text, flags=re.MULTILINE)
    # Remove the enum variant if no remaining references require it.
    text = re.sub(r"^\s*UsbTransfer,\s*\n", "", text, flags=re.MULTILINE)
    write(apps_mod, text)

manager = root / "vendor/pulp-os/src/apps/manager.rs"
if manager.exists():
    text = read(manager)
    text = text.replace(" | AppId::UsbTransfer", "")
    text = text.replace("AppId::UsbTransfer | ", "")
    # Remove obvious standalone match arms.
    text = re.sub(r"\n\s*AppId::UsbTransfer\s*=>\s*[^,\n]+,", "", text)
    text = re.sub(r"\n\s*AppId::UsbTransfer\s*=>\s*\{[^{}]*\},", "", text, flags=re.DOTALL)
    write(manager, text)

home = root / "vendor/pulp-os/src/apps/home.rs"
if home.exists():
    text = read(home)
    text = remove_function(text, "open_usb_transfer")
    text = text.replace('(5, 2) => "USB Transfer",\n', "")
    text = text.replace('(5, 2) => "Bulk SD transfer",\n', "")
    text = text.replace("Transition::Push(AppId::UsbTransfer)", "Transition::None")
    if "fn open_usb_transfer" in text and "#[allow(dead_code)]\n    fn open_usb_transfer" not in text:
        text = text.replace("    fn open_usb_transfer", "    #[allow(dead_code)]\n    fn open_usb_transfer", 1)
    write(home, text)


# ---------------------------------------------------------------------
# 4. Keep Wi-Fi Transfer two-tab UI; fail loudly if the current page is old.
# ---------------------------------------------------------------------
upload_html = root / "vendor/pulp-os/assets/upload.html"
if upload_html.exists():
    html = read(upload_html)
    if "Chunked Resume" not in html or "Original Transfer" not in html:
        errors.append("upload.html does not appear to contain the two-tab Wi-Fi Transfer UI")
    # Remove stale USB wording if any survived.
    html = html.replace("USB Transfer", "Wi-Fi Transfer")
    write(upload_html, html)


# ---------------------------------------------------------------------
# 5. Documentation.
# ---------------------------------------------------------------------
docs_dir = root / "docs"
docs_dir.mkdir(exist_ok=True)
doc = docs_dir / "prepared_reader_stabilization_cleanup.md"
write(doc, """# Prepared Reader Stabilization Cleanup

## What this stabilizes

- Prepared TXT/EPUB cache rendering remains the preferred path for mixed Latin + Devanagari books.
- Reader header shows `Prep Pg ...` when a prepared cache is active.
- Reader header shows `Read cache:<BOOKID> err:<CODE>` only when the prepared cache fails to open.
- Generic temporary `err:OPEN` debug text is removed from normal reading chrome.
- Wi-Fi Transfer keeps two tabs: `Original Transfer` and `Chunked Resume`.
- USB serial transfer scaffolding is removed when present because X4 does not provide normal USB mass-storage file transfer.

## Large FCACHE limits

The prepared reader now keeps real-book limits large enough for `YEARLY_H.TXT` style caches:

```text
MAX_META_BYTES  = 1024
MAX_INDEX_BYTES = 4 * 1024
MAX_FONT_BYTES  = 16 * 1024
MAX_PAGE_BYTES  = 24 * 1024
MAX_PAGES       = 192
MAX_GLYPHS      = 1024
```

These limits are intentionally higher than the original smoke-test values because real books can have larger `PAGES.IDX` files and larger `.VRN` pages.

## Validation checklist

```bash
cargo fmt --all --check
cargo check --workspace --target riscv32imc-unknown-none-elf
cargo clippy --workspace --target riscv32imc-unknown-none-elf -- -D warnings
cargo build -p target-xteink-x4 --release --target riscv32imc-unknown-none-elf
git diff --check
```

After flashing:

```text
YEARLY_H.TXT:
  Expected header: Prep Pg ...
  Expected body: Sanskrit/Hindi render without ??? placeholders.

Mixed EPUB smoke:
  Expected header: Prep Pg ...
  Expected body: Hindi/Sanskrit render without ??? placeholders.
```

If a prepared cache fails, the header should show one of:

```text
Read cache:<BOOKID> err:MISSING
Read cache:<BOOKID> err:META
Read cache:<BOOKID> err:BOOK
Read cache:<BOOKID> err:INDEX
Read cache:<BOOKID> err:FONT_MISSING
Read cache:<BOOKID> err:FONT
Read cache:<BOOKID> err:PAGE
Read cache:<BOOKID> err:TOO_LARGE
```

Use the `Chunked Resume` tab for large `/FCACHE/<BOOKID>` folders.
""")

readme = root / "README.md"
if readme.exists():
    text = read(readme)
    marker = "## Prepared Reader Stabilization"
    if marker not in text:
        addition = """

## Prepared Reader Stabilization

Prepared TXT/EPUB caches under `/FCACHE/<BOOKID>` are used for mixed-script books that need host-generated Noto glyph runs. When a cache opens successfully, Reader shows `Prep Pg ...`. If a cache fails, Reader shows `Read cache:<BOOKID> err:<CODE>` so the failing loader step can be diagnosed.

For large cache folders, use Wi-Fi Transfer's `Chunked Resume` tab. See `docs/prepared_reader_stabilization_cleanup.md` for limits and validation.
"""
        text = text.rstrip() + addition + "\n"
        write(readme, text)


# ---------------------------------------------------------------------
# 6. Remove old zip and overlay folders from repo root.
#    Keep this cleanup overlay if it is currently unpacked in the repo.
# ---------------------------------------------------------------------
keep_names = {"prepared_reader_stabilization_cleanup_overlay"}
for item in list(root.iterdir()):
    name = item.name
    if name in keep_names:
        continue
    if name.startswith(".git") or name == ".vaachak_backups":
        continue
    remove = False
    if name == "__MACOSX" or name == ".DS_Store":
        remove = True
    elif item.is_file() and name.endswith(".zip"):
        remove = True
    elif item.is_dir() and (name.endswith("_overlay") or name.endswith("_overlay_v2") or name.startswith("phase")):
        remove = True
    elif item.is_file() and name.startswith("phase") and name.endswith(".zip"):
        remove = True
    if remove:
        backup(item)
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()


if errors:
    print("prepared reader stabilization cleanup failed:", file=sys.stderr)
    for err in errors:
        print(f"- {err}", file=sys.stderr)
    print("\nBackups are under:", backup_root, file=sys.stderr)
    raise SystemExit(1)

print("Prepared Reader Stabilization Cleanup applied")
print(f"Backups are under: {backup_root}")
PY

cargo fmt --all

printf '\nPrepared reader limits:\n'
rg -n "MAX_META_BYTES|MAX_INDEX_BYTES|MAX_FONT_BYTES|MAX_PAGE_BYTES|MAX_PAGES|MAX_GLYPHS|source_matches" \
  vendor/pulp-os/src/apps/reader/prepared_txt.rs || true

printf '\nReader chrome diagnostics:\n'
rg -n "write_reader_status_label|err:OPEN|Read cache|Prep" \
  vendor/pulp-os/src/apps/reader/mod.rs || true

printf '\nRemaining USB transfer references:\n'
rg -n "UsbTransfer|usb_transfer|USB Transfer" vendor tools docs README.md || true
