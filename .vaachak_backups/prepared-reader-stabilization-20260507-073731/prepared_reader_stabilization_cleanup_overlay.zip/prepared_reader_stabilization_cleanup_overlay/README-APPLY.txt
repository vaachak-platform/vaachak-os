Prepared Reader Stabilization Cleanup

Apply from repository root:

  ./prepared_reader_stabilization_cleanup_overlay/scripts/apply_prepared_reader_stabilization_cleanup.sh .

Scope:
- Remove temporary generic err:OPEN/debug-only header text from normal reader chrome.
- Keep useful prepared-cache error-code diagnostics when cache open fails.
- Keep prepared cache limits high enough for YEARLY_H.TXT style FCACHE folders.
- Keep Wi-Fi Transfer two-tab UI.
- Remove unused USB serial transfer scaffolding when present.
- Add docs/prepared_reader_stabilization_cleanup.md.
- Remove old root zip files and overlay folders, with backups under .vaachak_backups/.

Validate:

  cargo fmt --all --check
  cargo check --workspace --target riscv32imc-unknown-none-elf
  cargo clippy --workspace --target riscv32imc-unknown-none-elf -- -D warnings
  cargo build -p target-xteink-x4 --release --target riscv32imc-unknown-none-elf
  git diff --check

Flash and verify:

  YEARLY_H.TXT header should show: Prep Pg ...
  Mixed EPUB smoke header should show: Prep Pg ...

If a cache fails, the header should show:

  Read cache:<BOOKID> err:<CODE>

where CODE is MISSING, META, BOOK, INDEX, FONT_MISSING, FONT, PAGE, or TOO_LARGE.
